---
name: Feature request
about: Request a new feature
title: ''
labels: enhancement
assignees: ''

---

Please browse the existing issues and filter by 'enhancement' to make sure this has not already been suggested!
